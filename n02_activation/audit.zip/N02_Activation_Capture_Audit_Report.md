# N02 Activation Capture Audit — v1.0

## Executive summary
The upload contains a **complete technical activation-capture run** for 400 text IDs and two model checkpoints. All 800 text-model jobs are marked COMPLETE; there are 9,600 metric rows, 12 block rows per job, no duplicate `(model_key, text_id, layer_idx)` keys, and all primary numeric metrics are finite.

However, **do not treat this as confirmatory Main Evaluation evidence**. The source preflight report has inconsistent gates: it reports `frozen_for_confirmatory_analysis: true` while the manifest role remains `candidate_main_eval_not_frozen`, and `human_review_of_replaced_items_done: false`. It also retains warnings about 24 code-mixed texts without domain words and 12 code templates that differ only in numbers. The capture metadata hashes match the reported frozen hash/text fingerprint, but hashes prove which file was used, not that the dataset approval criteria were satisfied.

## Technical integrity checks

- **capture_status:** `COMPLETE`
- **expected_text_model_jobs:** `800`
- **completed_text_model_jobs:** `800`
- **missing_text_model_jobs:** `0`
- **error_jobs:** `0`
- **metric_rows_actual:** `9600`
- **capture_status_rows:** `800`
- **unique_text_ids:** `400`
- **unique_topic_ids:** `100`
- **duplicate_metric_keys:** `0`
- **all_primary_numeric_metrics_finite:** `True`
- **output_input_ratio_identity_max_abs_residual:** `1.8118839761882555e-13`
- **metadata_manifest_hash_matches_report_frozen_hash:** `True`
- **metadata_text_fingerprint_matches_report:** `True`

## Capture configuration
- Protocol: `N02_Main_Evaluation_Activation_Capture_v1.0`
- Environment: Python `3.13.15`, PyTorch `2.11.0+cu130`, Transformers `5.18.0`
- Device: `Tesla T4` / `cuda`
- Models: GPT-2 and Pythia-160M; hidden dimensions recorded in CSV.
- Manifest SHA-256 used: `9cdf829ba0f7a1e4da51e95270f96943ffb7a65b441ed6fd3c11840e887b0c17`
- Text fingerprint SHA-256: `3a5835d8a65c1a383332c4e1911c9944614139704adbd743f3116ac79a5c0f27`

## Layerwise descriptive findings (exploratory only)
- **gpt2:** mean input-update cosine ranges from `-0.408` to `0.748` across layers. Most negative mean is layer `11` (`-0.408`); highest mean is layer `3` (`0.748`). Final-block mean cosine `-0.408`, mean update/input ratio `1.085`, mean output/input ratio `1.129`.
- **pythia-160m:** mean input-update cosine ranges from `-0.616` to `0.473` across layers. Most negative mean is layer `10` (`-0.616`); highest mean is layer `3` (`0.473`). Final-block mean cosine `-0.188`, mean update/input ratio `3.001`, mean output/input ratio `2.980`.

These are descriptive summaries of the captured texts, not inferential claims. Since the code-mixed condition had unresolved semantic/template warnings, style contrasts involving it should remain exploratory and should be repeated after re-freezing a corrected manifest.

## Recommended disposition
1. Preserve this run and its hashes as `N02_capture_candidate_manifest_v1.0.3` (exploratory, not confirmatory). Do not delete the results.
2. Correct the seven syntax/topic examples and every remaining hard/warning issue. Recompute checks after edits, inspect token bands using each tokenizer, and obtain real human review.
3. Create a genuinely frozen manifest with role `main_eval_frozen`, `human_review...=true`, zero hard failures, zero prohibited duplicate templates, and an updated hash.
4. Run a new activation capture only on that frozen hash. Keep the present 9,600-row run separate from the confirmatory run.
5. After the valid capture, conduct 10,000-replicate topic-cluster bootstrap with all four styles retained in each sampled topic; do not resample 400 rows as independent observations.

## Files
- `N02_Layerwise_Descriptive_Summary.csv`
- `N02_Final_Block_By_Style_And_Tier.csv`
- `N02_By_Style_And_Length_Descriptive.csv`
- `N02_Overall_Style_Descriptive.csv`
- `N02_Capture_Audit.json`